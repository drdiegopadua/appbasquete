# Ideias de Design - Supercopa de Basquete de Afonso Cláudio

## Contexto
Aplicativo PWA para a Supercopa de Basquete de Afonso Cláudio. A arte fornecida apresenta uma identidade visual forte com cores vinho/dourado, efeitos de luz dinâmicos, tipografia em negrito e uma atmosfera de competição de alto nível.

---

## Resposta 1: Design Esportivo Luxuoso (Probabilidade: 0.08)

**Design Movement:** Art Deco Esportivo + Dark Luxury

**Core Principles:**
- Elegância através de contraste vinho/dourado em fundo escuro
- Tipografia geométrica e ousada que evoca poder e prestígio
- Hierarquia visual clara com linhas douradas como divisores
- Animações dinâmicas que refletem a energia do basquete

**Color Philosophy:**
- Primária: Vinho profundo (#6B1B2A) - confiança e prestígio
- Secundária: Dourado metálico (#D4AF37) - excelência e vitória
- Fundo: Preto/Charcoal (#0F0F0F) - dramaticidade
- Acentos: Laranja queimado (#CC5500) - energia e movimento
- Raciocínio: Cores remetem à arte fornecida, criando continuidade visual e evoção de competição de elite

**Layout Paradigm:**
- Assimétrico com blocos diagonais
- Seções com clip-path criando ângulos dinâmicos
- Sidebar esquerda com navegação vertical
- Conteúdo principal com grid de cards com bordas douradas

**Signature Elements:**
- Linhas douradas horizontais como separadores (efeito de "glow")
- Bordas em forma de escudo (referência à arte)
- Ícones de basquete integrados sutilmente
- Partículas/confete animadas em momentos de vitória

**Interaction Philosophy:**
- Hover effects com brilho dourado
- Transições suaves que reforçam a sensação de movimento
- Feedback visual imediato em cliques
- Modais com animação de entrada dinâmica

**Animation:**
- Entrada de elementos com fade + slide (200ms ease-out)
- Hover em cards: brilho dourado que cresce (150ms)
- Transições entre páginas com dissolve suave (250ms)
- Pulsação sutil em elementos de destaque (2s loop)

**Typography System:**
- Display: Playfair Display Bold (títulos majestosos)
- Body: Roboto (legibilidade em tamanhos menores)
- Hierarchy: Títulos em 48px/bold, subtítulos em 24px/semibold, corpo em 16px/regular

---

## Resposta 2: Design Moderno Minimalista Esportivo (Probabilidade: 0.07)

**Design Movement:** Modernismo Esportivo + Neumorfismo

**Core Principles:**
- Simplicidade com impacto visual através de tipografia grande
- Uso estratégico de espaço em branco
- Ênfase em dados e informações de forma limpa
- Animações sutis que não distraem

**Color Philosophy:**
- Primária: Vinho suave (#8B2E3B) - sofisticado mas acessível
- Secundária: Dourado suave (#C9A961) - luxo sem exagero
- Fundo: Branco/Off-white (#F8F7F5) - clareza
- Acentos: Cinza escuro (#2C2C2C) - contraste
- Raciocínio: Mantém identidade vinho/dourado mas em versão mais limpa e moderna

**Layout Paradigm:**
- Centrado com máximo de 1200px
- Uso generoso de padding e margens
- Cards com sombra suave (neumorfismo)
- Tipografia como elemento principal de design

**Signature Elements:**
- Linhas finas em vinho como divisores
- Badges com números (placar, ranking)
- Ícones simples e geométricos
- Tipografia em tamanhos variados como destaque

**Interaction Philosophy:**
- Transições suaves e previsíveis
- Feedback visual sutil
- Foco em usabilidade
- Microinterações que educam

**Animation:**
- Entrada suave com fade (150ms)
- Hover com mudança de cor sutil (100ms)
- Transições de página com slide suave (200ms)
- Sem animações excessivas

**Typography System:**
- Display: Montserrat Bold (títulos modernos)
- Body: Open Sans (legibilidade excelente)
- Hierarchy: Títulos em 40px/bold, subtítulos em 20px/semibold, corpo em 15px/regular

---

## Resposta 3: Design Energético com Gradientes Dinâmicos (Probabilidade: 0.06)

**Design Movement:** Brutalism Digital + Gradientes Vibrantes

**Core Principles:**
- Uso agressivo de gradientes vinho→dourado
- Tipografia pesada e impactante
- Layouts assimétricos e ousados
- Movimento constante através de animações

**Color Philosophy:**
- Gradiente primário: Vinho (#6B1B2A) → Dourado (#D4AF37)
- Gradiente secundário: Laranja (#FF6B35) → Vinho (#6B1B2A)
- Fundo: Preto com padrão de ruído sutil (#0F0F0F)
- Acentos: Branco puro (#FFFFFF) para contraste
- Raciocínio: Cria dinamismo visual e energia que reflete a competição

**Layout Paradigm:**
- Blocos sobrepostos com rotação
- Uso de clip-path para formas orgânicas
- Conteúdo fluindo em zigue-zague
- Sem grid rígido - mais orgânico

**Signature Elements:**
- Gradientes animados em backgrounds
- Formas geométricas sobrepostas
- Tipografia com gradiente aplicado
- Efeitos de blur e glow

**Interaction Philosophy:**
- Animações responsivas ao movimento do mouse
- Feedback visual explosivo
- Transições que chamam atenção
- Interatividade como parte da experiência

**Animation:**
- Entrada com bounce (300ms cubic-bezier)
- Hover com rotação leve + escala (150ms)
- Transições com morph de formas (400ms)
- Animações contínuas em backgrounds (looping)

**Typography System:**
- Display: Space Grotesk Bold (futurista e ousado)
- Body: Inter (legibilidade com personalidade)
- Hierarchy: Títulos em 56px/bold com gradiente, subtítulos em 28px/bold, corpo em 16px/regular

---

## Decisão: Design Esportivo Luxuoso (Art Deco Esportivo + Dark Luxury)

**Justificativa:**
- Alinha perfeitamente com a arte fornecida (vinho, dourado, efeitos de luz)
- Comunica prestígio e profissionalismo apropriado para um campeonato
- Oferece espaço para animações dinâmicas que reforçam a energia do basquete
- Tipografia ousada e geométrica diferencia o app de competidores
- Cores ricas e contrastantes garantem boa legibilidade e impacto visual
- Estrutura assimétrica evita layouts genéricos e cria experiência memorável

**Elementos que serão mantidos:**
- Paleta vinho/dourado como identidade visual
- Linhas douradas como elemento de design recorrente
- Tipografia bold e geométrica
- Fundo escuro para dramaticidade
- Animações que reforçam movimento e energia
